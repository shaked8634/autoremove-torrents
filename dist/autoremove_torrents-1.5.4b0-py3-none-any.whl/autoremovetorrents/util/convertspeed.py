from .convertbytes import convert_bytes

def convert_speed(byte):
     return ('%s/s' % convert_bytes(byte))