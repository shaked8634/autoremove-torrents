#-*- coding:utf-8 -*-

# Current autoremove-torrents version
__version__ = '1.5.4c1'
